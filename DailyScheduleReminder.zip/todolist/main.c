#include <stdio.h>
#include <stdlib.h>

typedef struct Schedule tasks;

struct Schedule{
 char info[100];
 tasks *link;
 int count;
};
void GreetingsUser();
void ViewTasks();
void CreateTasks();
void DeleteTasks();
void fixcount();
void UpdateTasks();
tasks *start=NULL;
int main()
{
    int selection;
    GreetingsUser();
    while(1)
    {
        printf("\n1.View Your Tasks");
        printf("\n2.Create Your Tasks");
        printf("\n3.Delete Your Tasks");
        printf("\n4.Update Your Tasks");
        printf("\n5.Exit");
        printf("\n\nEnter your selection...");
        scanf("%d",&selection);
        switch(selection)
        {
            case 1:
                ViewTasks();
                break;
            case 2:
                CreateTasks();
                break;
            case 3:
                DeleteTasks();
                break;
            case 4:
                UpdateTasks();
                break;
            case 5:
                exit(0);
        }
    }
}

void GreetingsUser()
{
   printf("\n\n\n\n\n");
   printf("\t-------------------------------------------------------------------------------------------------------\n\n");
   printf("\t##################################### DAILY SCHEDULE REMINDER #########################################\n\n");
   printf("\t-------------------------------------------------------------------------------------------------------");
   printf("\n\n\n\t\t\t\t\t\t***** GREETINGS *****\n\n\n\n\n\n\n\n\n\t\t");
}

void ViewTasks()
{
   tasks *temp;
   temp=start;
        if(start==NULL)
        {
            printf("\nEmpty SCHEDULE\n\n");
        }

        while(temp!=NULL)
        {
            printf("%d)",temp->count);
            puts(temp->info);
            fflush(stdin);
            temp=temp->link;
        }
        printf("\n\n\n");
}

void CreateTasks()
{
    char k;
    int i;
    tasks *t,*temp;
    while(1)
    {
        printf("\nNeed to append?");
        printf("\nEnter 'y' for Yes and 'n' for No\n");
        fflush(stdin);
        scanf("%c",&k);
        if(k=='y')
        {
             if(start==NULL)
             {
                 t=(tasks *)calloc(1,sizeof(tasks));
                 start=t;
                 printf("\nAppend the task...\n");
                 fflush(stdin);
                 gets(t->info);
                 t->count=1;
                 start->link=NULL;
             }
        else
        {
            temp=(tasks *)calloc(1,sizeof(tasks));
            printf("\nAppend the task...\n");
            fflush(stdin);
            gets(temp->info);
            temp->link=NULL;
            t->link=temp;
            t=t->link;
            fixcount();
        }
        }
        else if(k=='n')
            break;

   }
}

void DeleteTasks()
{
    int d;
    tasks *temp1,*temp;
    printf("\nEnter the task's number that you wish to delete\n");
    scanf("%d",&d);
    temp1=start;
    temp=start->link;
    while(1)
    {
        if(temp1->count==d)
        {
            start=start->link;
            free(temp1);
            fixcount();
            break;
        }
        else if(temp->count==d)
        {
            temp1->link=temp->link;
            free(temp);
            fixcount();
            break;
        }
        else
        {
            temp1=temp;
            temp=temp->link;
        }
    }
}

void fixcount()
{
    tasks *temp;
    int i=1;
    temp=start;
    while(temp!=NULL)
    {
        temp->count=i;
        i++;
        temp=temp->link;
    }

}

void UpdateTasks()
{
    tasks *temp,*t;
    char k;
    while(1)
    {
        printf("\nNeed to append?");
        printf("\nEnter 'y' for Yes and 'n' for No\n");
        fflush(stdin);
        scanf("%c",&k);
        if(k=='y')
        {
            printf("\nAppend the task...\n");
            temp=(tasks *)calloc(1,sizeof(tasks));
            fflush(stdin);
            gets(temp->info);
            temp->link=NULL;
            t=start;
            while(t->link!=NULL)
            {
                t=t->link;
            }
            t->link=temp;
        }

        if(k=='n')
            break;

        fixcount();
    }
printf("\n\n");
}
